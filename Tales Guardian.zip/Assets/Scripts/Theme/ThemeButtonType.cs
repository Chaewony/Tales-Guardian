﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ThemeButtonType
{
    //테마 씬
    ThemeHome, //테마에서 로비로
    ThemeSetting, // 테마에서 설정 창 열기
    ThemeSettingClose, // 테마에서 설정 창 닫기
    ThemeGameQuit
}
