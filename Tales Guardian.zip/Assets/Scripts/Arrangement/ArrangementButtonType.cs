﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum ArrangementButtonType
{
    //배치 씬
    Team1,
    Team2,
    Team3,
    Theme1,
    Theme2,
    Theme3,
    Theme4,
    Theme5,
    DefType,
    AtkType,
    SupType,
    All,
    CloseArragement,
    Field0,
    Field1,
    Field2,
    Field3,
    Field4,
    Field5,
    Field6,
    Field7,
    Field8,
    AllArrangementReset
}
