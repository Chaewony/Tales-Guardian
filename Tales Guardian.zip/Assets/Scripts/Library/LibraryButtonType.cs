﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum LibraryButtonType
{
     OnceDraw, // 1회뽑기
     TenTimesDraw, // 10회뽑기
     SeePercentage, // 확률확인
     CloseSeepercnetage,
     CloseTenTimesDraw,
     CloseOnceDraw,
     Close // 창 닫기
}
